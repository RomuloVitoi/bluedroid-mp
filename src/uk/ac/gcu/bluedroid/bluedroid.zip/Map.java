package uk.ac.gcu.bluedroid;

import android.content.Context;
import android.widget.Toast;

public class Map {
    int[][] selectedMap;
    
    private Context context;
    
	private Unit[][] units;
	private Resource[][] resources;
	
	public Map(Context context) {
		this.context = context;
		
		selectedMap = Maps.map1;
		
		units = new Unit[selectedMap.length][selectedMap[0].length];
		resources = new Resource[selectedMap.length][selectedMap[0].length];
		
		int player = 1;
		for(int i = 0; i < getX(); i++)
			for(int j = 0; j < getY(); j++){
				int selected = selectedMap[j][i];
				switch (selected) {
				case 5:
					addUnit(new Paladin(player, new Position(i, j+1)));
					addUnit(new Archer(player, new Position(i-1, j)));
					addUnit(new Soldier(player, new Position(i+1, j)));
					player++;
					break;
				case 2:
					addResource(new Camp(0,new Position(i, j)));
					break;
				case 3:
					addResource(new Mine(0,new Position(i, j)));
					break;
				case 4:
					addResource(new Crop(0,new Position(i, j)));
					break;
				default:
					break;
				}
			}
	}
	
	public int getX() {
		return selectedMap[0].length;
	}
	
	public int getY() {
		return selectedMap.length;
	}
	
	public void addUnit(Unit u) {
		units[u.getPosition().y][u.getPosition().x] = u;
	}
	
	public void addResource(Resource r) {
		resources[r.getPosition().y][r.getPosition().x] = r;
	}
	
	public void conquerResource(Resource r, Unit unit, String type){
		if(r.owner==0){
			Toast.makeText(context, "Player " + unit.owner + " conquered a " + type, Toast.LENGTH_SHORT).show();
		}else{
			Toast.makeText(context, "Player " + unit.owner + " conquered a " + type + " from Player " + r.owner, Toast.LENGTH_SHORT).show();
		}
		r.owner = unit.owner;
	}
	
	public Unit getUnit(int x, int y) {
		return units[y][x];
	}
	
	public Resource getResource(int x, int y) {
		return resources[y][x];
	}
	
	public void moveUnit(Unit unit, int x, int y) {
		units[y][x] = unit;
		units[unit.getPosition().y][unit.getPosition().x] = null;
		units[y][x].walk(new Position(x, y));
		
		//conquer functions
		int type = getSquareType(x, y);
		if(type == 2 || type == 3 || type == 4){
			switch(type){
			case 2:
				conquerResource(new Camp(unit.owner, new Position(x, y)), unit, "camp");
				break;
			case 3:
				conquerResource(new Mine(unit.owner, new Position(x, y)), unit, "mine");
				break;
			case 4:
				conquerResource(new Crop(unit.owner, new Position(x, y)), unit, "crop");
				break;
			}
		}
	}
	
	public void removeUnit(Unit unit) {
		units[unit.getPosition().y][unit.getPosition().x] = null;
	}
	
	public boolean walkable(int x, int y) {
		if(units[y][x] != null)
			return false;
		
		switch(getSquareType(x, y)) {
		case 0:
		case 2:
		case 3:
		case 4:
		case 5:
			return true;
		default:
			return false;
		}
	}
	
	public boolean canWalkTo(int x0, int y0, int x1, int y1, int range) {
		boolean able = true;
		int disX = Math.abs(x0 - x1);
		int disY = Math.abs(y0 - y1);

		if ((disX + disY) > range) return false;
		if (disX > 0 && disY > 0) return false;
		if (disX > 0)
			for (int i = 1; i <= disX; i++) {
				if (!walkable((x0 + i), y0)) {
					able = false;
					break;
				}
			}
		else {
			for (int i = 1; i <= disY; i++) {
				if (!walkable(x0, (y0 + i))) {
					able = false;
					break;
				}
			}
		}
		return able;
	}
	
	public int getSquareType (int x, int y){
		return selectedMap[y][x];
	}


}
